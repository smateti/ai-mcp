@echo off
REM llama.cpp Multi-Service Setup
REM LLM (8000) + Embedding (8001) + Reranker (8002)
REM Run as Administrator!

echo.
echo ╔══════════════════════════════════════════════════════════════╗
echo ║     llama.cpp Multi-Service Quick Setup                       ║
echo ║     LLM (8000) + Embedding (8001) + Reranker (8002)          ║
echo ╚══════════════════════════════════════════════════════════════╝
echo.

REM Check for admin rights
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo ERROR: This script requires Administrator privileges!
    echo Right-click and select "Run as administrator"
    pause
    exit /b 1
)

set INSTALL_PATH=C:\llama-server

echo Installation Path: %INSTALL_PATH%
echo.

REM Check for Ollama models
echo Checking for required Ollama models...
echo.

if exist "%USERPROFILE%\.ollama\models" (
    echo [OK] Ollama models directory found
) else (
    echo [WARNING] Ollama models not found!
    echo.
    echo Please install required models first:
    echo.
    echo   REM LLM Models
    echo   ollama pull llama3.1:8b-instruct-q4_K_M
    echo   ollama pull granite3.1-dense:8b
    echo.
    echo   REM Embedding Model
    echo   ollama pull nomic-embed-text
    echo.
    echo   REM Reranker Model  
    echo   ollama pull bge-reranker-v2-m3:latest
    echo.
    pause
)

echo.
echo Starting setup...
echo.

powershell -ExecutionPolicy Bypass -File "%~dp0setup.ps1" -InstallPath "%INSTALL_PATH%"

if %errorLevel% neq 0 (
    echo.
    echo Setup failed! Check error messages above.
    pause
    exit /b 1
)

echo.
echo ╔══════════════════════════════════════════════════════════════╗
echo ║                    Setup Complete!                            ║
echo ╚══════════════════════════════════════════════════════════════╝
echo.
echo Services:
echo   LLM Server:       http://localhost:8000
echo   Embedding Server: http://localhost:8001
echo   Reranker Server:  http://localhost:8002
echo.
echo Quick Commands:
echo   Check status:  %INSTALL_PATH%\scripts\status.ps1
echo   Start all:     %INSTALL_PATH%\scripts\start-all.ps1
echo   Stop all:      %INSTALL_PATH%\scripts\stop-all.ps1
echo.
echo Test endpoints:
echo   curl http://localhost:8000/health
echo   curl http://localhost:8001/health
echo   curl http://localhost:8002/health
echo.

pause

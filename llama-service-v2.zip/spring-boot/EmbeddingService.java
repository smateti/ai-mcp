package com.example.agent.service.embedding;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import jakarta.annotation.PostConstruct;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Service for generating text embeddings using llama.cpp embedding server.
 * Connects to nomic-embed-text or other embedding models.
 */
@Service
@Slf4j
public class EmbeddingService {
    
    private final WebClient webClient;
    private final ObjectMapper objectMapper;
    
    @Value("${llama.embedding.base-url:http://localhost:8001}")
    private String baseUrl;
    
    @Value("${llama.embedding.timeout-seconds:30}")
    private int timeoutSeconds;
    
    @Value("${llama.embedding.dimension:768}")
    private int dimension;
    
    @Value("${llama.embedding.normalize:true}")
    private boolean normalize;
    
    @Value("${llama.embedding.batch-size:32}")
    private int batchSize;
    
    public EmbeddingService(WebClient.Builder webClientBuilder, ObjectMapper objectMapper) {
        this.webClient = webClientBuilder
            .codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(16 * 1024 * 1024))
            .build();
        this.objectMapper = objectMapper;
    }
    
    @PostConstruct
    public void init() {
        log.info("Initializing EmbeddingService: {} (dimension: {})", baseUrl, dimension);
        checkHealth();
    }
    
    private void checkHealth() {
        try {
            webClient.get()
                .uri(baseUrl + "/health")
                .retrieve()
                .bodyToMono(String.class)
                .timeout(Duration.ofSeconds(5))
                .block();
            log.info("Embedding server health check passed");
        } catch (Exception e) {
            log.warn("Embedding server not available: {}", e.getMessage());
        }
    }
    
    /**
     * Generate embedding for a single text
     */
    public float[] embed(String text) {
        List<float[]> embeddings = embedBatch(List.of(text));
        return embeddings.isEmpty() ? new float[0] : embeddings.get(0);
    }
    
    /**
     * Generate embeddings for multiple texts (batched)
     */
    public List<float[]> embedBatch(List<String> texts) {
        if (texts == null || texts.isEmpty()) {
            return Collections.emptyList();
        }
        
        List<float[]> allEmbeddings = new ArrayList<>();
        
        // Process in batches
        for (int i = 0; i < texts.size(); i += batchSize) {
            List<String> batch = texts.subList(i, Math.min(i + batchSize, texts.size()));
            List<float[]> batchEmbeddings = processBatch(batch);
            allEmbeddings.addAll(batchEmbeddings);
        }
        
        return allEmbeddings;
    }
    
    private List<float[]> processBatch(List<String> texts) {
        try {
            List<float[]> results = new ArrayList<>();
            
            for (String text : texts) {
                Map<String, Object> request = Map.of(
                    "content", text
                );
                
                String response = webClient.post()
                    .uri(baseUrl + "/embedding")
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(request)
                    .retrieve()
                    .bodyToMono(String.class)
                    .timeout(Duration.ofSeconds(timeoutSeconds))
                    .block();
                
                JsonNode root = objectMapper.readTree(response);
                JsonNode embeddingNode = root.path("embedding");
                
                float[] embedding = new float[embeddingNode.size()];
                for (int i = 0; i < embeddingNode.size(); i++) {
                    embedding[i] = (float) embeddingNode.get(i).asDouble();
                }
                
                if (normalize) {
                    embedding = normalizeVector(embedding);
                }
                
                results.add(embedding);
            }
            
            return results;
            
        } catch (Exception e) {
            log.error("Embedding batch failed", e);
            throw new EmbeddingServiceException("Failed to generate embeddings: " + e.getMessage(), e);
        }
    }
    
    /**
     * Normalize vector to unit length
     */
    private float[] normalizeVector(float[] vector) {
        double norm = 0.0;
        for (float v : vector) {
            norm += v * v;
        }
        norm = Math.sqrt(norm);
        
        if (norm > 0) {
            float[] normalized = new float[vector.length];
            for (int i = 0; i < vector.length; i++) {
                normalized[i] = (float) (vector[i] / norm);
            }
            return normalized;
        }
        return vector;
    }
    
    /**
     * Calculate cosine similarity between two vectors
     */
    public float cosineSimilarity(float[] a, float[] b) {
        if (a.length != b.length) {
            throw new IllegalArgumentException("Vectors must have same dimension");
        }
        
        float dotProduct = 0;
        float normA = 0;
        float normB = 0;
        
        for (int i = 0; i < a.length; i++) {
            dotProduct += a[i] * b[i];
            normA += a[i] * a[i];
            normB += b[i] * b[i];
        }
        
        return (float) (dotProduct / (Math.sqrt(normA) * Math.sqrt(normB)));
    }
    
    /**
     * Get embedding dimension
     */
    public int getDimension() {
        return dimension;
    }
    
    /**
     * Check if service is available
     */
    public boolean isAvailable() {
        try {
            webClient.get()
                .uri(baseUrl + "/health")
                .retrieve()
                .bodyToMono(String.class)
                .timeout(Duration.ofSeconds(5))
                .block();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    public static class EmbeddingServiceException extends RuntimeException {
        public EmbeddingServiceException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}

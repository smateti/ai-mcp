package com.example.agent.service.reranker;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Builder;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import jakarta.annotation.PostConstruct;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Service for reranking documents using llama.cpp reranker server.
 * Uses BGE Reranker v2 M3 or similar cross-encoder models.
 */
@Service
@Slf4j
public class RerankerService {
    
    private final WebClient webClient;
    private final ObjectMapper objectMapper;
    
    @Value("${llama.reranker.base-url:http://localhost:8002}")
    private String baseUrl;
    
    @Value("${llama.reranker.timeout-seconds:30}")
    private int timeoutSeconds;
    
    @Value("${llama.reranker.top-k:10}")
    private int defaultTopK;
    
    public RerankerService(WebClient.Builder webClientBuilder, ObjectMapper objectMapper) {
        this.webClient = webClientBuilder
            .codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(16 * 1024 * 1024))
            .build();
        this.objectMapper = objectMapper;
    }
    
    @PostConstruct
    public void init() {
        log.info("Initializing RerankerService: {}", baseUrl);
        checkHealth();
    }
    
    private void checkHealth() {
        try {
            webClient.get()
                .uri(baseUrl + "/health")
                .retrieve()
                .bodyToMono(String.class)
                .timeout(Duration.ofSeconds(5))
                .block();
            log.info("Reranker server health check passed");
        } catch (Exception e) {
            log.warn("Reranker server not available: {}", e.getMessage());
        }
    }
    
    /**
     * Rerank documents based on relevance to query
     * 
     * @param query The search query
     * @param documents List of documents to rerank
     * @param topK Number of top documents to return (null = all)
     * @return Reranked documents with scores
     */
    public List<RankedDocument> rerank(String query, List<String> documents, Integer topK) {
        if (documents == null || documents.isEmpty()) {
            return Collections.emptyList();
        }
        
        int k = (topK != null && topK > 0) ? topK : defaultTopK;
        k = Math.min(k, documents.size());
        
        try {
            List<RankedDocument> results = new ArrayList<>();
            
            // Score each document against the query
            for (int i = 0; i < documents.size(); i++) {
                String document = documents.get(i);
                float score = scoreDocument(query, document);
                
                results.add(RankedDocument.builder()
                    .index(i)
                    .document(document)
                    .score(score)
                    .build());
            }
            
            // Sort by score (descending) and take top-k
            return results.stream()
                .sorted((a, b) -> Float.compare(b.getScore(), a.getScore()))
                .limit(k)
                .collect(Collectors.toList());
                
        } catch (Exception e) {
            log.error("Reranking failed", e);
            throw new RerankerServiceException("Failed to rerank documents: " + e.getMessage(), e);
        }
    }
    
    /**
     * Rerank with document objects that have additional metadata
     */
    public <T> List<RankedItem<T>> rerankItems(String query, List<T> items, 
                                                java.util.function.Function<T, String> textExtractor,
                                                Integer topK) {
        if (items == null || items.isEmpty()) {
            return Collections.emptyList();
        }
        
        List<String> texts = items.stream()
            .map(textExtractor)
            .collect(Collectors.toList());
        
        List<RankedDocument> rankedDocs = rerank(query, texts, topK);
        
        return rankedDocs.stream()
            .map(rd -> RankedItem.<T>builder()
                .item(items.get(rd.getIndex()))
                .score(rd.getScore())
                .originalIndex(rd.getIndex())
                .build())
            .collect(Collectors.toList());
    }
    
    /**
     * Score a single query-document pair
     */
    public float scoreDocument(String query, String document) {
        try {
            // llama.cpp reranking endpoint
            // The reranker expects a query-document pair
            Map<String, Object> request = Map.of(
                "query", query,
                "documents", List.of(document)
            );
            
            String response = webClient.post()
                .uri(baseUrl + "/rerank")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(request)
                .retrieve()
                .bodyToMono(String.class)
                .timeout(Duration.ofSeconds(timeoutSeconds))
                .block();
            
            JsonNode root = objectMapper.readTree(response);
            
            // Response format: {"results": [{"index": 0, "score": 0.95}]}
            JsonNode results = root.path("results");
            if (results.isArray() && results.size() > 0) {
                return (float) results.get(0).path("score").asDouble();
            }
            
            // Alternative: direct score response
            if (root.has("score")) {
                return (float) root.path("score").asDouble();
            }
            
            return 0.0f;
            
        } catch (Exception e) {
            log.warn("Failed to score document: {}", e.getMessage());
            return 0.0f;
        }
    }
    
    /**
     * Batch rerank with explicit scoring (alternative endpoint)
     */
    public List<RankedDocument> rerankBatch(String query, List<String> documents) {
        try {
            Map<String, Object> request = Map.of(
                "query", query,
                "documents", documents
            );
            
            String response = webClient.post()
                .uri(baseUrl + "/rerank")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(request)
                .retrieve()
                .bodyToMono(String.class)
                .timeout(Duration.ofSeconds(timeoutSeconds))
                .block();
            
            JsonNode root = objectMapper.readTree(response);
            JsonNode results = root.path("results");
            
            List<RankedDocument> ranked = new ArrayList<>();
            
            if (results.isArray()) {
                for (JsonNode result : results) {
                    int index = result.path("index").asInt();
                    float score = (float) result.path("score").asDouble();
                    
                    ranked.add(RankedDocument.builder()
                        .index(index)
                        .document(documents.get(index))
                        .score(score)
                        .build());
                }
            }
            
            // Sort by score descending
            ranked.sort((a, b) -> Float.compare(b.getScore(), a.getScore()));
            
            return ranked;
            
        } catch (Exception e) {
            log.error("Batch reranking failed", e);
            throw new RerankerServiceException("Batch reranking failed: " + e.getMessage(), e);
        }
    }
    
    /**
     * Check if service is available
     */
    public boolean isAvailable() {
        try {
            webClient.get()
                .uri(baseUrl + "/health")
                .retrieve()
                .bodyToMono(String.class)
                .timeout(Duration.ofSeconds(5))
                .block();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    // ========== DTOs ==========
    
    @Data
    @Builder
    public static class RankedDocument {
        private int index;
        private String document;
        private float score;
    }
    
    @Data
    @Builder
    public static class RankedItem<T> {
        private T item;
        private float score;
        private int originalIndex;
    }
    
    public static class RerankerServiceException extends RuntimeException {
        public RerankerServiceException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}

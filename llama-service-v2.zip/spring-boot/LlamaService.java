package com.example.agent.service.llm;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Service for interacting with llama.cpp server.
 * Supports grammar-constrained generation for consistent output formatting.
 */
@Service
@Slf4j
public class LlamaService {
    
    private final WebClient webClient;
    private final ObjectMapper objectMapper;
    private final ResourceLoader resourceLoader;
    
    // Configuration
    @Value("${llama.base-url:http://localhost:8080}")
    private String baseUrl;
    
    @Value("${llama.timeout-seconds:120}")
    private int timeoutSeconds;
    
    @Value("${llama.inference.temperature:0.1}")
    private double temperature;
    
    @Value("${llama.inference.top-p:0.9}")
    private double topP;
    
    @Value("${llama.inference.top-k:40}")
    private int topK;
    
    @Value("${llama.inference.repeat-penalty:1.1}")
    private double repeatPenalty;
    
    @Value("${llama.inference.max-tokens:2048}")
    private int maxTokens;
    
    @Value("${llama.inference.stop-tokens:Observation:,User Question:}")
    private List<String> stopTokens;
    
    @Value("${llama.grammar.enabled:true}")
    private boolean grammarEnabled;
    
    @Value("${llama.grammar.default:react}")
    private String defaultGrammar;
    
    @Value("${llama.grammar.files.react:}")
    private String reactGrammarPath;
    
    @Value("${llama.grammar.files.json:}")
    private String jsonGrammarPath;
    
    @Value("${llama.grammar.files.tool_call:}")
    private String toolCallGrammarPath;
    
    @Value("${llama.retry.max-attempts:3}")
    private int maxRetryAttempts;
    
    @Value("${llama.retry.initial-delay-ms:1000}")
    private long initialRetryDelay;
    
    // Cached grammars
    private final Map<String, String> grammarCache = new ConcurrentHashMap<>();
    
    public LlamaService(WebClient.Builder webClientBuilder, ObjectMapper objectMapper, ResourceLoader resourceLoader) {
        this.webClient = webClientBuilder
            .codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(16 * 1024 * 1024))
            .build();
        this.objectMapper = objectMapper;
        this.resourceLoader = resourceLoader;
    }
    
    @PostConstruct
    public void init() {
        log.info("Initializing LlamaService with base URL: {}", baseUrl);
        loadGrammars();
        checkServerHealth();
    }
    
    private void loadGrammars() {
        if (!grammarEnabled) {
            log.info("Grammar support disabled");
            return;
        }
        
        Map<String, String> grammarPaths = Map.of(
            "react", reactGrammarPath,
            "json", jsonGrammarPath,
            "tool_call", toolCallGrammarPath
        );
        
        grammarPaths.forEach((name, path) -> {
            if (path != null && !path.isBlank()) {
                try {
                    String content = Files.readString(Path.of(path), StandardCharsets.UTF_8);
                    grammarCache.put(name, content);
                    log.info("Loaded grammar '{}' from {}", name, path);
                } catch (IOException e) {
                    log.warn("Could not load grammar '{}' from {}: {}", name, path, e.getMessage());
                }
            }
        });
    }
    
    private void checkServerHealth() {
        try {
            String response = webClient.get()
                .uri(baseUrl + "/health")
                .retrieve()
                .bodyToMono(String.class)
                .timeout(Duration.ofSeconds(10))
                .block();
            
            log.info("llama.cpp server health check passed: {}", response);
        } catch (Exception e) {
            log.warn("llama.cpp server health check failed: {}. Server may not be running.", e.getMessage());
        }
    }
    
    /**
     * Generate completion with default grammar (ReAct pattern)
     */
    public String generate(String systemPrompt, String userPrompt) {
        return generateWithGrammar(systemPrompt, userPrompt, grammarEnabled ? defaultGrammar : null);
    }
    
    /**
     * Generate completion with specified grammar
     */
    public String generateWithGrammar(String systemPrompt, String userPrompt, String grammarName) {
        String fullPrompt = formatLlama3Prompt(systemPrompt, userPrompt);
        
        Map<String, Object> request = new HashMap<>();
        request.put("prompt", fullPrompt);
        request.put("temperature", temperature);
        request.put("top_p", topP);
        request.put("top_k", topK);
        request.put("repeat_penalty", repeatPenalty);
        request.put("n_predict", maxTokens);
        request.put("stop", stopTokens);
        request.put("stream", false);
        
        // Add grammar if specified and available
        if (grammarName != null && grammarCache.containsKey(grammarName)) {
            request.put("grammar", grammarCache.get(grammarName));
            log.debug("Using grammar: {}", grammarName);
        }
        
        return executeWithRetry(request);
    }
    
    /**
     * Generate completion with raw JSON request
     */
    public String generateRaw(Map<String, Object> request) {
        return executeWithRetry(request);
    }
    
    /**
     * Chat completion (OpenAI-compatible endpoint)
     */
    public String chat(List<Map<String, String>> messages) {
        Map<String, Object> request = Map.of(
            "messages", messages,
            "temperature", temperature,
            "max_tokens", maxTokens,
            "stream", false
        );
        
        try {
            String response = webClient.post()
                .uri(baseUrl + "/v1/chat/completions")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(request)
                .retrieve()
                .bodyToMono(String.class)
                .timeout(Duration.ofSeconds(timeoutSeconds))
                .block();
            
            JsonNode root = objectMapper.readTree(response);
            return root.path("choices").get(0).path("message").path("content").asText();
            
        } catch (Exception e) {
            log.error("Chat completion failed", e);
            throw new LlamaServiceException("Chat completion failed: " + e.getMessage(), e);
        }
    }
    
    private String executeWithRetry(Map<String, Object> request) {
        Exception lastException = null;
        long delay = initialRetryDelay;
        
        for (int attempt = 1; attempt <= maxRetryAttempts; attempt++) {
            try {
                log.debug("Attempt {}/{} - Sending request to llama.cpp", attempt, maxRetryAttempts);
                
                String response = webClient.post()
                    .uri(baseUrl + "/completion")
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(request)
                    .retrieve()
                    .bodyToMono(String.class)
                    .timeout(Duration.ofSeconds(timeoutSeconds))
                    .block();
                
                JsonNode root = objectMapper.readTree(response);
                String content = root.path("content").asText();
                
                if (log.isDebugEnabled()) {
                    int tokensGenerated = root.path("tokens_predicted").asInt(0);
                    log.debug("Generated {} tokens", tokensGenerated);
                }
                
                return content;
                
            } catch (WebClientResponseException e) {
                lastException = e;
                log.warn("Attempt {} failed with HTTP {}: {}", attempt, e.getStatusCode(), e.getMessage());
                
                // Don't retry on client errors (4xx)
                if (e.getStatusCode().is4xxClientError()) {
                    throw new LlamaServiceException("Client error: " + e.getMessage(), e);
                }
                
            } catch (Exception e) {
                lastException = e;
                log.warn("Attempt {} failed: {}", attempt, e.getMessage());
            }
            
            // Wait before retry
            if (attempt < maxRetryAttempts) {
                try {
                    Thread.sleep(delay);
                    delay = Math.min(delay * 2, 10000); // Exponential backoff, max 10s
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new LlamaServiceException("Interrupted during retry", ie);
                }
            }
        }
        
        throw new LlamaServiceException("All retry attempts failed", lastException);
    }
    
    /**
     * Format prompt using Llama 3 instruction template
     */
    private String formatLlama3Prompt(String systemPrompt, String userPrompt) {
        return """
            <|begin_of_text|><|start_header_id|>system<|end_header_id|>
            
            %s<|eot_id|><|start_header_id|>user<|end_header_id|>
            
            %s<|eot_id|><|start_header_id|>assistant<|end_header_id|>
            
            """.formatted(systemPrompt, userPrompt);
    }
    
    /**
     * Check if server is available
     */
    public boolean isAvailable() {
        try {
            webClient.get()
                .uri(baseUrl + "/health")
                .retrieve()
                .bodyToMono(String.class)
                .timeout(Duration.ofSeconds(5))
                .block();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Get available grammars
     */
    public List<String> getAvailableGrammars() {
        return List.copyOf(grammarCache.keySet());
    }
    
    /**
     * Load custom grammar at runtime
     */
    public void loadGrammar(String name, String grammarContent) {
        grammarCache.put(name, grammarContent);
        log.info("Loaded custom grammar: {}", name);
    }
    
    /**
     * Get server info
     */
    public Map<String, Object> getServerInfo() {
        try {
            String response = webClient.get()
                .uri(baseUrl + "/props")
                .retrieve()
                .bodyToMono(String.class)
                .timeout(Duration.ofSeconds(10))
                .block();
            
            return objectMapper.readValue(response, Map.class);
        } catch (Exception e) {
            log.warn("Could not get server info: {}", e.getMessage());
            return Map.of("error", e.getMessage());
        }
    }
    
    /**
     * Custom exception for LlamaService errors
     */
    public static class LlamaServiceException extends RuntimeException {
        public LlamaServiceException(String message) {
            super(message);
        }
        
        public LlamaServiceException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}

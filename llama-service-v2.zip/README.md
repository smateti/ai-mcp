# llama.cpp Multi-Service Setup for Windows 11

Production-ready llama.cpp server setup with three services for RAG applications.

## Services

| Service | Port | Model | Purpose |
|---------|------|-------|---------|
| **LLM Server** | 8000 | llama3.1, granite3.1 | Text generation, tool calling |
| **Embedding Server** | 8001 | nomic-embed-text | Document/query embeddings |
| **Reranker Server** | 8002 | bge-reranker-v2-m3 | Document reranking |

## Quick Start

### 1. Install Required Ollama Models

```powershell
# LLM Models
ollama pull llama3.1:8b-instruct-q4_K_M
ollama pull granite3.1-dense:8b

# Embedding Model
ollama pull nomic-embed-text

# Reranker Model
ollama pull bge-reranker-v2-m3:latest
```

### 2. Run Setup (as Administrator)

```powershell
.\quick-setup.bat
```

Or with PowerShell:

```powershell
.\setup.ps1 -InstallPath "C:\llama-server"
```

### 3. Verify Services

```powershell
# Check all services
.\scripts\status.ps1

# Test endpoints
curl http://localhost:8000/health
curl http://localhost:8001/health
curl http://localhost:8002/health
```

## Directory Structure

```
C:\llama-server\
├── bin\                      # llama.cpp binaries
│   ├── llama-server.exe
│   └── ggml-cuda.dll
├── models\                   # Linked Ollama models
│   ├── llama3.1_8b-instruct-q4_K_M.gguf -> ...
│   ├── nomic-embed-text_latest.gguf -> ...
│   └── bge-reranker-v2-m3_latest.gguf -> ...
├── config\
│   ├── server-config.json    # Main configuration
│   └── grammars\
│       ├── react.gbnf        # ReAct pattern grammar
│       ├── json.gbnf         # JSON output grammar
│       └── tool_call.gbnf    # Tool calling grammar
├── logs\                     # Service logs
│   ├── LlamaCppLLM.log
│   ├── LlamaCppEmbedding.log
│   └── LlamaCppReranker.log
├── scripts\
│   ├── status.ps1            # Check all services
│   ├── start-all.ps1         # Start all services
│   ├── stop-all.ps1          # Stop all services
│   └── test-service.ps1      # Test endpoints
└── nssm\
    └── nssm.exe              # Service manager
```

## API Endpoints

### LLM Server (Port 8000)

```bash
# Health check
curl http://localhost:8000/health

# Text completion
curl -X POST http://localhost:8000/completion \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Hello, how are you?",
    "n_predict": 100,
    "temperature": 0.1
  }'

# With grammar constraint (consistent output)
curl -X POST http://localhost:8000/completion \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "List 3 colors",
    "n_predict": 100,
    "grammar": "root ::= \"[\" item (\", \" item)* \"]\"\nitem ::= \"\\\"\" [a-z]+ \"\\\"\""
  }'
```

### Embedding Server (Port 8001)

```bash
# Health check
curl http://localhost:8001/health

# Generate embedding
curl -X POST http://localhost:8001/embedding \
  -H "Content-Type: application/json" \
  -d '{
    "content": "This is a sample document for embedding"
  }'
```

### Reranker Server (Port 8002)

```bash
# Health check
curl http://localhost:8002/health

# Rerank documents
curl -X POST http://localhost:8002/rerank \
  -H "Content-Type: application/json" \
  -d '{
    "query": "What is machine learning?",
    "documents": [
      "Machine learning is a subset of AI",
      "The weather is nice today",
      "Deep learning uses neural networks"
    ]
  }'
```

## Configuration

### server-config.json

Edit to change active models or ports:

```json
{
  "active_models": {
    "llm": "llama3.1-8b-instruct",
    "embedding": "nomic-embed-text",
    "reranker": "bge-reranker-v2-m3"
  },
  "services": {
    "llm": { "port": 8000 },
    "embedding": { "port": 8001 },
    "reranker": { "port": 8002 }
  }
}
```

### Available Models

#### LLM Models
| Model | Ollama Name | Size | Best For |
|-------|-------------|------|----------|
| Llama 3.1 8B | `llama3.1:8b-instruct-q4_K_M` | 4.7 GB | General tasks |
| Llama 3.1 70B | `llama3.1:70b-instruct-q4_K_M` | 40 GB | Best quality |
| Granite 3.1 8B | `granite3.1-dense:8b` | 4.9 GB | Enterprise/Code |
| Granite Code 34B | `granite-code:34b-instruct` | 20 GB | COBOL analysis |

#### Embedding Models
| Model | Ollama Name | Dimensions |
|-------|-------------|------------|
| Nomic Embed | `nomic-embed-text` | 768 |
| MxBai Large | `mxbai-embed-large` | 1024 |
| All MiniLM | `all-minilm` | 384 |

#### Reranker Models
| Model | Ollama Name | Notes |
|-------|-------------|-------|
| BGE v2 M3 | `bge-reranker-v2-m3:latest` | Multilingual |
| BGE Large | `bge-reranker-large:latest` | English |

## Service Management

```powershell
# Windows Service Commands
Start-Service LlamaCppLLM
Start-Service LlamaCppEmbedding
Start-Service LlamaCppReranker

Stop-Service LlamaCppLLM
Stop-Service LlamaCppEmbedding
Stop-Service LlamaCppReranker

Restart-Service LlamaCppLLM

# Check status
Get-Service LlamaCpp*

# View logs
Get-Content C:\llama-server\logs\LlamaCppLLM.log -Tail 50
```

## Spring Boot Integration

Copy the files from `spring-boot/` to your project:

- `application.yml` - Configuration
- `LlamaService.java` - LLM client with grammar support
- `EmbeddingService.java` - Embedding client
- `RerankerService.java` - Reranker client

Example usage:

```java
@Autowired
private LlamaService llamaService;

@Autowired  
private EmbeddingService embeddingService;

@Autowired
private RerankerService rerankerService;

// Generate text with grammar constraint
String response = llamaService.generateWithGrammar(
    systemPrompt, 
    userPrompt, 
    "react"  // Forces ReAct format output
);

// Generate embeddings
float[] queryEmbedding = embeddingService.embed("search query");
List<float[]> docEmbeddings = embeddingService.embedBatch(documents);

// Rerank retrieved documents
List<RankedDocument> ranked = rerankerService.rerank(
    query, 
    retrievedDocs, 
    5  // top-k
);
```

## Grammar Files (Consistent Output)

### ReAct Grammar (`react.gbnf`)
Forces output in exact ReAct format:
```
Thought: I need to find the services first
Action: getServicesByApplication
Action Input: {"applicationName": "PaymentSystem"}
```

### JSON Grammar (`json.gbnf`)
Forces valid JSON object output.

### Tool Call Grammar (`tool_call.gbnf`)
Forces structured tool calling format.

## Troubleshooting

### Service won't start
```powershell
# Check logs
Get-Content C:\llama-server\logs\LlamaCppLLM-error.log

# Verify model exists
dir C:\llama-server\models\

# Test manually
C:\llama-server\bin\llama-server.exe --model "path\to\model.gguf" --port 8000
```

### Model not found
```powershell
# Re-link Ollama models
.\setup.ps1 -SkipModelLink:$false
```

### Out of memory
- Reduce `--ctx-size` in config
- Use smaller quantization (q4 instead of q8)
- Check GPU memory with `nvidia-smi`

### Slow performance
- Ensure GPU layers are set: `--n-gpu-layers 99`
- Enable flash attention: `--flash-attn`
- Check GPU utilization with `nvidia-smi`

## Requirements

- Windows 11
- NVIDIA GPU with CUDA 12.x+ (RTX 5090 tested)
- NVIDIA Driver 570+
- Ollama installed with models pulled
- Administrator privileges for service installation

## Performance (RTX 5090)

| Model | Tokens/sec |
|-------|-----------|
| Llama 3.1 8B Q4 | ~150-180 |
| Granite 3.1 8B | ~140-160 |
| Nomic Embed | ~1000+ |
| BGE Reranker | ~500+ |

$ollamaBase = "$env:USERPROFILE\.ollama\models"
$models = @(
    @{ name="llama3.1"; tag="8b-instruct-q4_K_M"; ns="library" },
    @{ name="llama3.1"; tag="latest"; ns="library" },
    @{ name="nomic-embed-text"; tag="latest"; ns="library" },
    @{ name="bge-reranker-v2-m3"; tag="latest"; ns="qllama" }
)
foreach ($m in $models) {
    $manifestPath = Join-Path $ollamaBase "manifests\registry.ollama.ai\$($m.ns)\$($m.name)\$($m.tag)"
    if (Test-Path $manifestPath) {
        $manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json
        $layer = $manifest.layers | Where-Object { $_.mediaType -eq "application/vnd.ollama.image.model" }
        $blobName = $layer.digest -replace "sha256:", "sha256-"
        $blobPath = Join-Path $ollamaBase "blobs\$blobName"
        $exists = Test-Path $blobPath
        Write-Output "$($m.name):$($m.tag) -> $blobPath (exists: $exists)"
    } else {
        Write-Output "$($m.name):$($m.tag) -> NOT FOUND"
    }
}

# Note: NSSM service install requires Administrator privileges
<#
.SYNOPSIS
    Setup script for llama.cpp Multi-Model Server (single port, INI-based)

.DESCRIPTION
    This script sets up a single llama.cpp server instance that serves
    all models (LLM, Embedding, Reranker) on one port using --models-preset.
    Models are lazy-loaded on demand and grammar files ensure consistent output.

    Server: http://localhost:8000 (all models)
    Models: llama3.1, granite-code, nomic-embed-text, all-minilm, bge-reranker-v2-m3

.PARAMETER InstallPath
    Installation directory (default: C:\llama-server)

.PARAMETER Port
    Server port (default: 8000)

.PARAMETER ModelsMax
    Maximum models loaded simultaneously (default: 6)

.EXAMPLE
    .\setup.ps1
    .\setup.ps1 -Port 8000 -ModelsMax 4
#>

param(
    [string]$InstallPath = "C:\llama-server",
    [string]$LlamaCppVersion = "b7926",
    [int]$Port = 8000,
    [int]$ModelsMax = 6,
    [switch]$SkipDownload,
    [switch]$Uninstall
)

$ErrorActionPreference = "Stop"

# ============================================================
# CONFIGURATION
# ============================================================

$NSSM_VERSION = "2.24"
$NSSM_URL = "https://nssm.cc/release/nssm-$NSSM_VERSION.zip"

$SERVICE_NAME = "LlamaCppServer"
$SERVICE_DISPLAY = "llama.cpp Multi-Model Server"
$SERVICE_DESC = "llama.cpp server with LLM, Embedding, and Reranker models on port $Port"

$STABLE_RELEASES = @{
    "b7926" = @{
        "url" = "https://github.com/ggml-org/llama.cpp/releases/download/b7926/llama-b7926-bin-win-cuda-13.1-x64.zip"
        "cuda_dlls" = "https://github.com/ggml-org/llama.cpp/releases/download/b7926/cudart-llama-bin-win-cuda-13.1-x64.zip"
        "cuda" = "13.1"
        "notes" = "Latest stable with CUDA 13.1, grammar, and multi-model support"
    }
}

# ============================================================
# HELPER FUNCTIONS
# ============================================================

function Write-Header {
    param([string]$Text)
    Write-Host ""
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host "  $Text" -ForegroundColor Cyan
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host ""
}

function Write-Step {
    param([string]$Text)
    Write-Host "[*] $Text" -ForegroundColor Green
}

function Write-Warn {
    param([string]$Text)
    Write-Host "[!] $Text" -ForegroundColor Yellow
}

function Write-Err {
    param([string]$Text)
    Write-Host "[X] $Text" -ForegroundColor Red
}

function Test-Administrator {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# ============================================================
# RESOLVE OLLAMA BLOB PATH
# ============================================================

function Get-OllamaBlobPath {
    param(
        [string]$OllamaName  # e.g. "llama3.1:latest" or "qllama/bge-reranker-v2-m3:latest"
    )

    $ollamaBase = "$env:USERPROFILE\.ollama\models"
    $manifestsBase = "$ollamaBase\manifests\registry.ollama.ai"

    # Parse namespace/model:tag
    $parts = $OllamaName -split "/"
    if ($parts.Count -eq 2) {
        $namespace = $parts[0]
        $modelTag = $parts[1]
    } else {
        $namespace = "library"
        $modelTag = $parts[0]
    }

    $tagParts = $modelTag -split ":"
    $modelName = $tagParts[0]
    $tag = if ($tagParts.Count -gt 1) { $tagParts[1] } else { "latest" }

    $manifestPath = Join-Path $manifestsBase "$namespace\$modelName\$tag"

    if (-not (Test-Path $manifestPath)) { return $null }

    try {
        $manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json
        $modelLayer = $manifest.layers | Where-Object { $_.mediaType -eq "application/vnd.ollama.image.model" }
        if ($modelLayer) {
            $blobName = $modelLayer.digest -replace "sha256:", "sha256-"
            $blobPath = "$ollamaBase\blobs\$blobName"
            if (Test-Path $blobPath) { return $blobPath }
        }
    } catch { }

    return $null
}

# ============================================================
# GENERATE INI FILE FROM server-config.json
# ============================================================

function Generate-ModelPreset {
    param([string]$InstallPath)

    Write-Header "Generating Model Preset (llama.ini)"

    $configPath = "$InstallPath\config\server-config.json"
    $iniPath = "$InstallPath\config\llama.ini"
    $config = Get-Content $configPath -Raw | ConvertFrom-Json

    $ini = @()

    # Global settings
    $ini += "# llama.cpp Multi-Model Preset"
    $ini += "# Generated from server-config.json"
    $ini += "# All models served on single port via --models-preset"
    $ini += ""
    $ini += "[*]"
    $ini += "ngl = $($config.hardware.gpu_layers)"
    if ($config.hardware.flash_attention) {
        $ini += "fa = true"
    }
    $ini += "host = $($config.server_defaults.host)"
    $ini += ""

    $modelCount = 0

    # Active models first
    foreach ($modelKey in $config.active_models.PSObject.Properties) {
        $category = $modelKey.Name       # "llm", "embedding", "reranker"
        $activeModel = $modelKey.Value    # e.g. "llama3.1-8b-instruct"

        $modelConfig = $config.models.$category.$activeModel
        if (-not $modelConfig) {
            Write-Warn "Active model '$activeModel' not found in models.$category"
            continue
        }

        # Resolve model path
        $modelPath = $null
        if ($modelConfig.path -and (Test-Path $modelConfig.path)) {
            $modelPath = $modelConfig.path
        } elseif ($modelConfig.ollama_name) {
            $modelPath = Get-OllamaBlobPath -OllamaName $modelConfig.ollama_name
        }

        if (-not $modelPath) {
            Write-Warn "Model file not found for $activeModel (ollama: $($modelConfig.ollama_name))"
            Write-Warn "  Pull it: ollama pull $($modelConfig.ollama_name)"
            continue
        }

        $alias = $activeModel

        $ini += "# $($modelConfig.name) - $($modelConfig.description)"
        $ini += "[$alias]"
        $ini += "model = $modelPath"
        $ini += "ctx-size = $($modelConfig.ctx_size)"

        if ($category -eq "embedding") {
                $ini += "embeddings = true"
                if ($modelConfig.pooling) {
                    $ini += "pooling = $($modelConfig.pooling)"
                }
                $ini += "batch-size = 2048"
                $ini += "ubatch-size = 2048"
            }

        if ($category -eq "reranker") {
                $ini += "reranking = true"
            }

        $ini += ""
        $modelCount++
        Write-Step "Added: $alias ($($modelConfig.name)) [$category]"
    }

    # Inactive models (available for hot-swap)
    foreach ($category in @("llm", "embedding", "reranker")) {
        $models = $config.models.$category
        if (-not $models) { continue }
        $activeModel = $config.active_models.$category

        foreach ($prop in $models.PSObject.Properties) {
            $modelKey = $prop.Name
            if ($modelKey -eq $activeModel) { continue }

            $modelConfig = $prop.Value
            $modelPath = $null

            if ($modelConfig.path -and (Test-Path $modelConfig.path)) {
                $modelPath = $modelConfig.path
            } elseif ($modelConfig.ollama_name) {
                $modelPath = Get-OllamaBlobPath -OllamaName $modelConfig.ollama_name
            }

            if (-not $modelPath) { continue }

            $alias = $modelKey
            $ini += "# $($modelConfig.name) (inactive - available for hot-swap)"
            $ini += "[$alias]"
            $ini += "model = $modelPath"
            $ini += "ctx-size = $($modelConfig.ctx_size)"

            if ($category -eq "embedding") {
                $ini += "embeddings = true"
                if ($modelConfig.pooling) { $ini += "pooling = $($modelConfig.pooling)" }
            }

            if ($category -eq "reranker") {
                $ini += "reranking = true"
            }

            $ini += ""
            $modelCount++
            Write-Step "Added: $alias ($($modelConfig.name)) [$category] (inactive)"
        }
    }

    $iniContent = $ini -join "`n"
    [System.IO.File]::WriteAllText($iniPath, $iniContent, [System.Text.UTF8Encoding]::new($false))

    Write-Step "Generated $iniPath with $modelCount models"
    return $iniPath
}

# ============================================================
# INSTALLATION FUNCTIONS
# ============================================================

function Install-LlamaCpp {
    param([string]$DestPath)

    Write-Header "Installing llama.cpp ($LlamaCppVersion)"

    $release = $STABLE_RELEASES[$LlamaCppVersion]
    if (-not $release) {
        throw "Unknown version: $LlamaCppVersion. Available: $($STABLE_RELEASES.Keys -join ', ')"
    }

    $binPath = "$DestPath\bin"

    # Download main binary
    $zipFile = "$env:TEMP\llama-cpp.zip"
    $extractPath = "$env:TEMP\llama-cpp-extract"

    Write-Step "Downloading llama.cpp $LlamaCppVersion (CUDA $($release.cuda))..."
    Invoke-WebRequest -Uri $release.url -OutFile $zipFile -UseBasicParsing

    Write-Step "Extracting..."
    if (Test-Path $extractPath) { Remove-Item $extractPath -Recurse -Force }
    Expand-Archive -Path $zipFile -DestinationPath $extractPath -Force

    if (-not (Test-Path $binPath)) { New-Item -ItemType Directory -Path $binPath -Force | Out-Null }

    $sourceDir = Get-ChildItem $extractPath -Directory | Select-Object -First 1
    if ($sourceDir) { $sourceDir = $sourceDir.FullName } else { $sourceDir = $extractPath }

    Copy-Item "$sourceDir\*" -Destination $binPath -Recurse -Force

    Remove-Item $zipFile -Force -ErrorAction SilentlyContinue
    Remove-Item $extractPath -Recurse -Force -ErrorAction SilentlyContinue

    # Download CUDA runtime DLLs
    if ($release.cuda_dlls) {
        Write-Step "Downloading CUDA $($release.cuda) runtime DLLs..."
        $cudaZip = "$env:TEMP\cuda-dlls.zip"
        $cudaExtract = "$env:TEMP\cuda-dlls-extract"

        Invoke-WebRequest -Uri $release.cuda_dlls -OutFile $cudaZip -UseBasicParsing

        if (Test-Path $cudaExtract) { Remove-Item $cudaExtract -Recurse -Force }
        Expand-Archive -Path $cudaZip -DestinationPath $cudaExtract -Force

        Get-ChildItem $cudaExtract -Recurse -Filter "*.dll" | Copy-Item -Destination $binPath -Force
        Write-Step "CUDA DLLs installed"

        Remove-Item $cudaZip -Force -ErrorAction SilentlyContinue
        Remove-Item $cudaExtract -Recurse -Force -ErrorAction SilentlyContinue
    }

    if (Test-Path "$binPath\llama-server.exe") {
        Write-Step "llama.cpp installed: $binPath\llama-server.exe"

        @{
            "version" = $LlamaCppVersion
            "cuda" = $release.cuda
            "mode" = "multi-model"
            "installed" = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
        } | ConvertTo-Json | Out-File "$DestPath\version.json"
    } else {
        throw "Installation failed - llama-server.exe not found"
    }
}

function Install-NSSM {
    param([string]$DestPath)

    Write-Header "Installing NSSM"

    $nssmPath = "$DestPath\nssm"
    $nssmExe = "$nssmPath\nssm.exe"

    if (Test-Path $nssmExe) {
        Write-Step "NSSM already installed"
        return $nssmExe
    }

    $zipFile = "$env:TEMP\nssm.zip"
    $extractPath = "$env:TEMP\nssm-extract"

    Write-Step "Downloading NSSM..."
    Invoke-WebRequest -Uri $NSSM_URL -OutFile $zipFile -UseBasicParsing

    Expand-Archive -Path $zipFile -DestinationPath $extractPath -Force

    if (-not (Test-Path $nssmPath)) { New-Item -ItemType Directory -Path $nssmPath -Force | Out-Null }

    $sourceExe = Get-ChildItem $extractPath -Recurse -Filter "nssm.exe" |
                 Where-Object { $_.DirectoryName -match "win64" } |
                 Select-Object -First 1

    Copy-Item $sourceExe.FullName -Destination $nssmExe -Force

    Remove-Item $zipFile -Force -ErrorAction SilentlyContinue
    Remove-Item $extractPath -Recurse -Force -ErrorAction SilentlyContinue

    Write-Step "NSSM installed: $nssmExe"
    return $nssmExe
}

function Install-Service {
    param(
        [string]$InstallPath,
        [string]$NssmExe,
        [string]$IniPath
    )

    Write-Header "Installing Windows Service"

    $serverExe = "$InstallPath\bin\llama-server.exe"
    $logDir = "$InstallPath\logs"

    # Stop and remove existing
    $existing = Get-Service -Name $SERVICE_NAME -ErrorAction SilentlyContinue
    if ($existing) {
        Write-Step "Removing existing service..."
        Stop-Service -Name $SERVICE_NAME -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2
        & $NssmExe remove $SERVICE_NAME confirm 2>$null
        Start-Sleep -Seconds 1
    }

    $argsString = "--models-preset `"$IniPath`" --port $Port --models-max $ModelsMax --flash-attn on"

    Write-Step "Arguments: $argsString"

    & $NssmExe install $SERVICE_NAME $serverExe
    & $NssmExe set $SERVICE_NAME AppParameters $argsString
    & $NssmExe set $SERVICE_NAME AppDirectory $InstallPath
    & $NssmExe set $SERVICE_NAME DisplayName $SERVICE_DISPLAY
    & $NssmExe set $SERVICE_NAME Description $SERVICE_DESC
    & $NssmExe set $SERVICE_NAME Start SERVICE_AUTO_START
    & $NssmExe set $SERVICE_NAME ObjectName LocalSystem

    & $NssmExe set $SERVICE_NAME AppExit Default Restart
    & $NssmExe set $SERVICE_NAME AppRestartDelay 5000
    & $NssmExe set $SERVICE_NAME AppThrottle 60000

    & $NssmExe set $SERVICE_NAME AppStdout "$logDir\llama-server.log"
    & $NssmExe set $SERVICE_NAME AppStderr "$logDir\llama-server-error.log"
    & $NssmExe set $SERVICE_NAME AppStdoutCreationDisposition 4
    & $NssmExe set $SERVICE_NAME AppStderrCreationDisposition 4
    & $NssmExe set $SERVICE_NAME AppRotateFiles 1
    & $NssmExe set $SERVICE_NAME AppRotateBytes 104857600

    & $NssmExe set $SERVICE_NAME AppEnvironmentExtra "CUDA_VISIBLE_DEVICES=0"

    Write-Step "Service installed: $SERVICE_NAME"
    return $true
}

function Create-ManagementScripts {
    param([string]$InstallPath)

    Write-Header "Creating Management Scripts"

    $scriptsPath = "$InstallPath\scripts"
    if (-not (Test-Path $scriptsPath)) {
        New-Item -ItemType Directory -Path $scriptsPath -Force | Out-Null
    }

    # Start script (manual, no admin needed)
    $startContent = @"
# Start llama.cpp multi-model server manually (no admin required)
Write-Host "Starting llama.cpp multi-model server on port $Port..." -ForegroundColor Cyan
Start-Process "$InstallPath\bin\llama-server.exe" -ArgumentList "--models-preset `"$InstallPath\config\llama.ini`" --port $Port --models-max $ModelsMax --flash-attn on" -WindowStyle Minimized
Write-Host "Server starting (minimized window)..." -ForegroundColor Green
Write-Host "Check: http://localhost:$Port/health"
"@
    Set-Content -Path "$scriptsPath\start.ps1" -Value $startContent -Encoding UTF8

    # Stop script
    $stopContent = @"
# Stop llama.cpp server
Write-Host "Stopping llama.cpp server..." -ForegroundColor Yellow
`$svc = Get-Service -Name "$SERVICE_NAME" -ErrorAction SilentlyContinue
if (`$svc -and `$svc.Status -eq "Running") {
    Stop-Service -Name "$SERVICE_NAME" -Force
    Write-Host "Service stopped" -ForegroundColor Green
} else {
    Get-Process -Name "llama-server" -ErrorAction SilentlyContinue | Stop-Process -Force
    Write-Host "Process stopped" -ForegroundColor Green
}
"@
    Set-Content -Path "$scriptsPath\stop.ps1" -Value $stopContent -Encoding UTF8

    # Status script
    $statusContent = @"
# Status of llama.cpp multi-model server
Write-Host ""
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "|     llama.cpp Multi-Model Server (port $Port)                 |" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

try {
    `$health = Invoke-RestMethod -Uri "http://localhost:$Port/health" -TimeoutSec 3
    Write-Host "  Health:   OK" -ForegroundColor Green
} catch {
    Write-Host "  Health:   Not Responding" -ForegroundColor Red
    return
}

try {
    `$models = Invoke-RestMethod -Uri "http://localhost:$Port/v1/models" -TimeoutSec 3
    Write-Host "  Models:" -ForegroundColor Cyan
    foreach (`$m in `$models.data) {
        `$c = if (`$m.status.value -eq "loaded") { "Green" } else { "Gray" }
        Write-Host "    `$(`$m.id) [`$(`$m.status.value)]" -ForegroundColor `$c
    }
} catch { }

Write-Host ""
try {
    `$gpu = & nvidia-smi --query-gpu=name,memory.used,memory.total --format=csv,noheader,nounits 2>`$null
    if (`$gpu) {
        `$i = `$gpu -split ','
        Write-Host "  GPU:    `$(`$i[0].Trim())  |  `$(`$i[1].Trim()) / `$(`$i[2].Trim()) MB"
    }
} catch { }
Write-Host ""
"@
    Set-Content -Path "$scriptsPath\status.ps1" -Value $statusContent -Encoding UTF8

    Write-Step "Created management scripts in $scriptsPath"
}

# ============================================================
# MAIN
# ============================================================

Write-Host ""
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "|     llama.cpp Multi-Model Server Setup                        |" -ForegroundColor Cyan
Write-Host "|     Single port ($Port) - All models via --models-preset      |" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Administrator)) {
    Write-Warn "Not running as Administrator. NSSM service install will be skipped."
    Write-Warn "Server can still be started manually via scripts\start.ps1"
}

# Create directories
Write-Step "Creating directory structure..."
@(
    $InstallPath,
    "$InstallPath\bin",
    "$InstallPath\config",
    "$InstallPath\config\grammars",
    "$InstallPath\logs",
    "$InstallPath\scripts",
    "$InstallPath\nssm"
) | ForEach-Object {
    if (-not (Test-Path $_)) {
        New-Item -ItemType Directory -Path $_ -Force | Out-Null
    }
}

# Install llama.cpp binary + CUDA DLLs
if (-not $SkipDownload) {
    Install-LlamaCpp -DestPath $InstallPath
}

# Copy config files from source
$sourceConfig = "$PSScriptRoot\config"
if (Test-Path $sourceConfig) {
    Copy-Item "$sourceConfig\*" -Destination "$InstallPath\config" -Recurse -Force
    Write-Step "Config files copied (including grammars)"
}

# Generate INI from server-config.json
$iniPath = Generate-ModelPreset -InstallPath $InstallPath

# Install NSSM + service (admin only)
if (Test-Administrator) {
    $nssmExe = Install-NSSM -DestPath $InstallPath
    Install-Service -InstallPath $InstallPath -NssmExe $nssmExe -IniPath $iniPath

    Write-Header "Starting Service"
    Start-Service -Name $SERVICE_NAME -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 5

    $svc = Get-Service -Name $SERVICE_NAME -ErrorAction SilentlyContinue
    if ($svc -and $svc.Status -eq "Running") {
        Write-Host "  [$SERVICE_NAME] " -NoNewline
        Write-Host "RUNNING" -ForegroundColor Green -NoNewline
        Write-Host " on port $Port"
    } else {
        Write-Warn "$SERVICE_NAME may not have started correctly"
        Write-Warn "Check logs: $InstallPath\logs\llama-server-error.log"
    }
} else {
    Write-Warn "Skipping NSSM service install (no admin). Use scripts\start.ps1 instead."
}

# Create management scripts
Create-ManagementScripts -InstallPath $InstallPath

# Summary
Write-Host ""
Write-Header "Setup Complete!"
Write-Host ""
Write-Host "  Installation: $InstallPath" -ForegroundColor White
Write-Host "  Server:       http://localhost:$Port" -ForegroundColor White
Write-Host "  INI Preset:   $InstallPath\config\llama.ini" -ForegroundColor White
Write-Host "  CUDA:         $($STABLE_RELEASES[$LlamaCppVersion].cuda)" -ForegroundColor White
Write-Host ""
Write-Host "  Grammar Files (for consistent output):" -ForegroundColor Yellow
$grammarDir = "$InstallPath\config\grammars"
Get-ChildItem $grammarDir -Filter "*.gbnf" -ErrorAction SilentlyContinue | ForEach-Object {
    Write-Host "    $($_.Name)"
}
Write-Host ""
Write-Host "  Quick Commands:" -ForegroundColor Yellow
Write-Host "    .\scripts\start.ps1             - Start server (no admin)"
Write-Host "    .\scripts\stop.ps1              - Stop server"
Write-Host "    .\scripts\status.ps1            - Check status + models"
Write-Host ""
Write-Host "  API (all on port $Port):" -ForegroundColor Yellow
Write-Host "    Chat:      POST /v1/chat/completions  {model: 'llama3.1-8b-instruct'}"
Write-Host "    Embedding: POST /v1/embeddings        {model: 'nomic-embed-text'}"
Write-Host "    Models:    GET  /v1/models"
Write-Host ""
Write-Host "  Grammar (pass in API request body for consistent output):" -ForegroundColor Yellow
Write-Host "    {""grammar"": ""<GBNF content>"", ...}"
Write-Host "    Available: json.gbnf, react.gbnf, tool_call.gbnf"
Write-Host ""
